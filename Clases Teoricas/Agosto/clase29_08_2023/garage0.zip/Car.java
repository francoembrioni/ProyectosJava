package garage0;

public class Car {
  private String plateNumber;
  
  public Car(String plateNumber ) {
      this.plateNumber = plateNumber;
  }
  
  public String getPlateNumber() {
      return plateNumber;
  }
  
}